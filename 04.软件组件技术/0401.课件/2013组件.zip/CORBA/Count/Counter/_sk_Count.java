package Counter;
// Warning: 
//   This class has been deprecated by the new IDL to Java Language mapping.
//   Please use the new implementation base class: _CountImplBase
abstract public class _sk_Count extends _CountImplBase {
  protected _sk_Count(java.lang.String name) {
    super(name);
  }
  protected _sk_Count() {
  }
}
