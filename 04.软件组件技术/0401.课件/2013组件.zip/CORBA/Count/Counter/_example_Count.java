package Counter;
public class _example_Count extends Counter._CountImplBase {
  public _example_Count(java.lang.String name) {
    super(name);
  }
  public _example_Count() {
    super();
  }
  public int increment() {
    // implement operation...
    return 0;
  }
  public void sum(int sum) {
    // implement attribute writer...
  }
  public int sum() {
    // implement attribute reader...
    return 0;
  }
}
