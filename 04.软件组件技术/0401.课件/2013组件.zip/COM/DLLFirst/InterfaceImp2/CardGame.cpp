#include "stdAfx.h"
#include "CardGame.h"
#include <iostream.h>

void CardGame::run( )
{
	cout << "CardGame is running" << endl;
}

