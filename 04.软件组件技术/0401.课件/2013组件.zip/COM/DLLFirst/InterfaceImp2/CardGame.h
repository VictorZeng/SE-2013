#ifndef _CardGame_h_
#define _CardGame_h_
#include "GameInterface.h"

class CardGame : public GameInterface
{
public:
	void run( );
};

#endif