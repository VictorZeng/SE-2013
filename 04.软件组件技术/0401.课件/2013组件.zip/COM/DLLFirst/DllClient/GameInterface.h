#ifndef _gameinterface_h_
#define _gameinterface_h_

class GameInterface
{
public:
	virtual void run( ) = 0;
};

#endif