#ifndef _DiceGame_h_
#define _DiceGame_h_
#include "GameInterface.h"

class DiceGame : public GameInterface
{
public:
	void run( );
};

#endif