#include "stdAfx.h"
#include "DiceGame.h"
#include <iostream.h>

void DiceGame::run( )
{
	cout << "DiceGame is running" << endl;
}

